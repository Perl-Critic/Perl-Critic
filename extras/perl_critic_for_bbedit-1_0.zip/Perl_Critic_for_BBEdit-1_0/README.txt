﻿Perl Critic for BBEdit
======================

    Josh Clark 
    Copyright 2006 Josh Clark and Global Moxie
    <http://beta.bigmedium.com/projects/bbedit-perl-critic/>  
    Version 1.0  
    August 28, 2006

    This AppleScript is released under a Creative Commons
    Attribution-ShareAlike License:  
    <http://creativecommons.org/licenses/by-sa/2.0/>
    
    Based on the CSS Syntax Check script for BBEdit by John Gruber:  
    <http://daringfireball.net/projects/csschecker/>
    
    ...and the Perl::Critic module by Jeffrey Ryan Thalhammer:  
    <http://search.cpan.org/dist/Perl-Critic/>
    
    ...and the "Perl Best Practices" book by Damian Conway:  
    <http://www.amazon.com/exec/obidos/ASIN/0596001738/globalmoxie-20>

What is it?
-----------

Perl Critic for BBEdit is an AppleScript plugin for the BBEdit text
editor that lets Perl programmers check their code against the style
recommendations of Damian Conway's book, Perl Best Practices. Warnings
are displayed in the results browser just like BBEdit's built-in Perl
and HTML syntax checkers.

Perl Critic for BBEdit requires Mac OS X 10.3.9 or later. It's been
tested against BBEdit 8.2.3. The Perl::Critic module must be
installed.

Credit All 'Round
-----------------

Perl Critic for BBEdit owes its thanks to three people, whose works I
can't recommend enough.

Jeffrey Ryan Thalhammer is creator of the Perl::Critic module, which
these scripts rely upon for all the dirty work. Perl::Critic analyzes
Perl code for compliance with style and syntax rules. Most of these
rules are based on the recommendations of the "Perl Best Practices"
book, but the system is not especially dogmatic. You can customize the
ruleset so that it enforces just the style rules that fit your
particular preferences or house style guide.

Damian Conway is a pillar of the Perl community and author of the
"Perl Best Practices" book, which has become a kind of defacto style
guide for the Perl language and a surprisingly good read to boot.

John Gruber of daringfireball.com wrote the excellent "CSS Syntax
Checker for BBEdit and TextWrangler," which inspired Perl Critic for
BBEdit. Much of the code is shamelessly swiped from Gruber.

Installation
------------

Perl Critic for BBEdit consists of two script files, one AppleScript
and one Perl:

* `Perl Critic.scpt`
* `Perl Critic.pl`

(A third file named `perlcriticrc` is also enclosed, more on that in a
sec.)

Put both scripts in your BBEdit scripts folder:

    ~/Library/Application Support/BBEdit/Scripts/

Be a Critic
-----------

Open a Perl script in BBedit and choose "Perl Critic" from the Scripts
menu. It will probably take a second or two to run, but can take
several seconds for longer scripts or those that have a large number
of warnings.

Any Perl Critics warnings will appear in a results browser, along with
references to the "Perl Best Practices" page numbers that describe the
problem, if applicable. Double clicking the item in the results
browser takes you to the line of problem code.

Customizing the Critic
----------------------

The Perl::Critic module allows you to customize the rules to be
enforced by adding a configuration file to your home directory
(`/Users/yourname`). The details are described in the Perl::Critic
documentation:
<http://search.cpan.org/dist/Perl-Critic/lib/Perl/Critic.pm#CONFIGURATION>

The configuration file lets you name a style rule and then set the
severity of that rule on a scale of 1 to 5, with 5 being most
important.

The included file `perlcriticrc` is a sample configuration file. Edit
it as you see fit, put it in your home directory, and rename it as
`.perlcriticrc` (i.e., precede the name with a dot).

By default, Perl Critic for BBedit flags any rule violation with a
severity of 2 or more. You can change this by editing the `Perl
Critic.pl` file:

    # severity is a number from 1 to 5 that determines what level of warnings to
    # report; the lower the value, the more strict the warnings and, probably,
    # the more warnings you'll receive
    my $SEVERITY = 2;
