#!/usr/bin/perl
use warnings;
use strict;
use Perl::Critic;

# severity is a number from 1 to 5 that determines what level of warnings to
# report; the lower the value, the more strict the warnings and, probably,
# the more warnings you'll receive
my $SEVERITY = 2;

my $path = $ARGV[0];
$Perl::Critic::Violation::FORMAT = "%l\t%m near '%r'. %e.";

my $critic = Perl::Critic->new( -severity => $SEVERITY );
print join( "\n", $critic->critique($path) );

exit;

